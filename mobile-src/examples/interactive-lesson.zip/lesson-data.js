window.CODEPAD_LESSON = {
  "format": "codepad-lesson-1",
  "title": "کسرهای مساوی؛ یک شکل، چند نام",
  "subject": "ریاضی · پایه هفتم",
  "description": "با دیدن شکل‌ها یاد بگیر چرا نصف، دو چهارم و چهار هشتم برابرند. ویدیو در سه نقطه می‌ایستد؛ پاسخ بده و ادامه بده.",
  "video": "media/fractions.webm",
  "poster": "media/cover.png",
  "font": "media/lesson-font.woff2",
  "requireCorrect": true,
  "checkpoints": [
    {
      "id": "half",
      "time": 4,
      "question": "در شکل اول چه بخشی از نوار رنگ شده است؟",
      "options": [
        "یک دوم",
        "یک چهارم",
        "سه چهارم",
        "یک هشتم"
      ],
      "correct": 0,
      "explanation": "یک قسمت از دو قسمت مساوی رنگ شده؛ یعنی یک دوم."
    },
    {
      "id": "quarters",
      "time": 10,
      "question": "کدام کسر با یک دوم برابر است؟",
      "options": [
        "یک چهارم",
        "دو چهارم",
        "سه چهارم",
        "چهار چهارم"
      ],
      "correct": 1,
      "explanation": "اگر هر نیمه را دوباره نصف کنیم، دو قسمت از چهار قسمت رنگ شده است."
    },
    {
      "id": "eighths",
      "time": 16,
      "question": "برای نوشتن یک دوم با مخرج ۸، صورت باید چند باشد؟",
      "options": [
        "۲",
        "۳",
        "۴",
        "۸"
      ],
      "correct": 2,
      "explanation": "صورت و مخرج یک دوم را در ۴ ضرب می‌کنیم: چهار هشتم."
    }
  ]
};
