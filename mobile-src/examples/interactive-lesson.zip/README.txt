CodePad 3.4 · Interactive lesson
Import this ZIP as a project, then run lesson.html.
Video, questions, poster and font are offline.
Edit questions in Studio > Media or lesson-data.js.
