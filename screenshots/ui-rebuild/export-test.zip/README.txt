CodePad · کارگاه آزمایش

Windows 10/11 · 64-bit

۱. کل فایل ZIP را استخراج کن.
۲. Start.exe را باز کن. پوشهٔ app باید کنار آن بماند.

برنامه از Edge یا Chrome برای نمایش استفاده می‌کند؛ اگر پیدا نشوند مرورگر پیش‌فرض باز می‌شود. پایتون و کدپد لازم نیست نصب باشند.
موتورهای زبان و پیوست‌ها همراه خروجی‌اند. کتابخانه‌های اضافهٔ Python یا منابع آنلاین پروژه ممکن است اینترنت بخواهند.
این بسته نسخهٔ قابل حمل است؛ نصب‌کننده ندارد. کد در موتورهای فعلی کدپد اجرا می‌شود.

Extract the entire ZIP, then double-click Start.exe. Keep the app folder beside it.
Uses Edge/Chrome or your default browser; no Python or CodePad installation is required.
Uses CodePad's existing browser runtimes. Extra packages/online resources may require internet.
This is a portable app, not an installer. The launcher is unsigned.
If startup fails, see CodePad-error.txt beside Start.exe.
