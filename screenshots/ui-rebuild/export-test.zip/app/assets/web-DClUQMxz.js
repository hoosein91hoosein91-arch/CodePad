import { n as e } from "./standalone-DSlJSeP3.js";
var t = class extends e {
  constructor() {
    (super(),
      (this.handleVisibilityChange = () => {
        let e = { isActive: document.hidden !== !0 };
        (this.notifyListeners(`appStateChange`, e),
          document.hidden ? this.notifyListeners(`pause`, null) : this.notifyListeners(`resume`, null));
      }),
      document.addEventListener(`visibilitychange`, this.handleVisibilityChange, !1));
  }
  exitApp() {
    throw this.unimplemented(`Not implemented on web.`);
  }
  async getInfo() {
    throw this.unimplemented(`Not implemented on web.`);
  }
  async getLaunchUrl() {
    return { url: `` };
  }
  async getState() {
    return { isActive: document.hidden !== !0 };
  }
  async minimizeApp() {
    throw this.unimplemented(`Not implemented on web.`);
  }
  async toggleBackButtonHandler() {
    throw this.unimplemented(`Not implemented on web.`);
  }
};
export { t as AppWeb };
