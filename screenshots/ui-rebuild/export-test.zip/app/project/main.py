# سلام دنیا
name = input()
print("سلام", name)